export interface Product {

  systemId: number;
  name: string;
  shelf: string;
  section: string;
  images: string[];

}
