
export interface Notification {

  systemId: number;
  productName: string;
  errorType: string;
  shelf: string;
  section: string;

}
