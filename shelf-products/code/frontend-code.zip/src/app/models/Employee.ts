
export interface Employee {

  systemId: number;
  name: string;
  mobile: string;

}
